<!--componets/Exam01.vue-->
<template>
  <!-- 先创建一个根元素 div-->
  <div class="app-exam01">
    <h3>练习组件创建</h3>
  </div>
</template>
<script>
  export default {//组件默认导出对象 
     data(){
       return {}  //组件操作数据 
     }
  }
</script>
<style>
  .app-exam01{
     color:red;
     font-size:16px;    
  }
</style>